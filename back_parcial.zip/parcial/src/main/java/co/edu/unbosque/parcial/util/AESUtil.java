package co.edu.unbosque.parcial.util;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

public class AESUtil {

	private static final String ALGORITMO = "AES";

	private static final String TIPOCIFRADO = "AES/GCM/NoPadding";

	private static final int TAG_BITS = 128;

	private static final int IV_BYTES = 12;

	private static final SecureRandom RANDOM = new SecureRandom();

	private static volatile String defaultKey;

	private AESUtil() {
	}

	public static void setDefaultKey(String llave) {
		toKey(llave);
		defaultKey = llave;
	}

	public static String encrypt(String llave, String iv, String texto) {
		try {
			Cipher cipher = Cipher.getInstance(TIPOCIFRADO);
			cipher.init(Cipher.ENCRYPT_MODE, toKey(llave), new GCMParameterSpec(TAG_BITS, iv.getBytes(UTF_8)));
			return Base64.encodeBase64String(cipher.doFinal(texto.getBytes(UTF_8)));
		} catch (GeneralSecurityException e) {
			throw new IllegalStateException("Could not encrypt the content", e);
		}
	}

	public static String decrypt(String llave, String iv, String encrypted) {
		try {
			Cipher cipher = Cipher.getInstance(TIPOCIFRADO);
			cipher.init(Cipher.DECRYPT_MODE, toKey(llave), new GCMParameterSpec(TAG_BITS, iv.getBytes(UTF_8)));
			return new String(cipher.doFinal(Base64.decodeBase64(encrypted)), UTF_8);
		} catch (GeneralSecurityException e) {
			throw new IllegalStateException("Could not decrypt the content", e);
		}
	}

	public static String encrypt(String plainText) {
		try {
			byte[] iv = new byte[IV_BYTES];
			RANDOM.nextBytes(iv);
			Cipher cipher = Cipher.getInstance(TIPOCIFRADO);
			cipher.init(Cipher.ENCRYPT_MODE, toKey(getDefaultKey()), new GCMParameterSpec(TAG_BITS, iv));
			byte[] encrypted = cipher.doFinal(plainText.getBytes(UTF_8));
			byte[] result = new byte[IV_BYTES + encrypted.length];
			System.arraycopy(iv, 0, result, 0, IV_BYTES);
			System.arraycopy(encrypted, 0, result, IV_BYTES, encrypted.length);
			return Base64.encodeBase64String(result);
		} catch (GeneralSecurityException e) {
			throw new IllegalStateException("Could not encrypt the content", e);
		}
	}

	public static String decrypt(String encrypted) {
		try {
			byte[] data = Base64.decodeBase64(encrypted);
			if (data.length <= IV_BYTES) {
				throw new IllegalArgumentException("Invalid encrypted content");
			}
			byte[] iv = Arrays.copyOfRange(data, 0, IV_BYTES);
			Cipher cipher = Cipher.getInstance(TIPOCIFRADO);
			cipher.init(Cipher.DECRYPT_MODE, toKey(getDefaultKey()), new GCMParameterSpec(TAG_BITS, iv));
			return new String(cipher.doFinal(data, IV_BYTES, data.length - IV_BYTES), UTF_8);
		} catch (GeneralSecurityException e) {
			throw new IllegalStateException("Could not decrypt the content", e);
		}
	}

	public static String hashingToSHA256(String content) {
		return DigestUtils.sha256Hex(content);
	}

	public static String hashingToSHA384(String content) {
		return DigestUtils.sha384Hex(content);
	}

	public static String hashingToSHA512(String content) {
		return DigestUtils.sha512Hex(content);
	}

	private static String getDefaultKey() {
		String llave = defaultKey;
		if (llave == null) {
			throw new IllegalStateException("The default AES key has not been configured");
		}
		return llave;
	}

	private static SecretKeySpec toKey(String llave) {
		byte[] bytes = llave.getBytes(UTF_8);
		if (bytes.length != 16 && bytes.length != 24 && bytes.length != 32) {
			throw new IllegalArgumentException("The AES key must be 16, 24 or 32 bytes long");
		}
		return new SecretKeySpec(bytes, ALGORITMO);
	}

}
