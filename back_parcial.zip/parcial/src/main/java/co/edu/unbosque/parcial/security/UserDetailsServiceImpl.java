package co.edu.unbosque.parcial.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	private final UserDetails defaultUser;

	public UserDetailsServiceImpl(@Value("${app.auth.username}") String username,
			@Value("${app.auth.password}") String password, PasswordEncoder passwordEncoder) {
		this.defaultUser = User.withUsername(username).password(passwordEncoder.encode(password)).roles("USER")
				.build();
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		if (!defaultUser.getUsername().equals(username)) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return defaultUser;
	}

}
