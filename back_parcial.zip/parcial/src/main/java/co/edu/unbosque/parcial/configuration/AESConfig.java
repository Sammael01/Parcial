package co.edu.unbosque.parcial.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import co.edu.unbosque.parcial.util.AESUtil;

@Configuration
public class AESConfig {

	public AESConfig(@Value("${aes.secret}") String secret) {
		AESUtil.setDefaultKey(secret);
	}

}
