package co.edu.unbosque.parcial.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import io.jsonwebtoken.JwtException;

class JwtUtilTest {

	private JwtUtil jwtUtil;
	private UserDetails user;

	@BeforeEach
	void setUp() {
		jwtUtil = new JwtUtil();
		ReflectionTestUtils.setField(jwtUtil, "secret", "changeThisJwtSecretKeyToAtLeast32Characters");
		ReflectionTestUtils.setField(jwtUtil, "expirationMs", 60000L);
		user = User.withUsername("admin").password("x").roles("USER").build();
	}

	@Test
	void generatedTokenIsValid() {
		String token = jwtUtil.generateToken(user);
		assertEquals("admin", jwtUtil.extractUsername(token));
		assertTrue(jwtUtil.validateToken(token, user));
	}

	@Test
	void tokenFromAnotherUserIsNotValid() {
		String token = jwtUtil.generateToken(user);
		UserDetails other = User.withUsername("other").password("x").roles("USER").build();
		assertFalse(jwtUtil.validateToken(token, other));
	}

	@Test
	void tamperedTokenIsRejected() {
		String token = jwtUtil.generateToken(user);
		String tampered = token.substring(0, token.length() - 2) + "xx";
		assertThrows(JwtException.class, () -> jwtUtil.extractUsername(tampered));
	}

	@Test
	void expiredTokenIsRejected() {
		ReflectionTestUtils.setField(jwtUtil, "expirationMs", -1000L);
		String token = jwtUtil.generateToken(user);
		assertThrows(JwtException.class, () -> jwtUtil.extractUsername(token));
	}

}
