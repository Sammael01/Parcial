package co.edu.unbosque.parcial.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AESUtilTest {

	@BeforeAll
	static void setUp() {
		AESUtil.setDefaultKey("changeThisAesKey");
	}

	@Test
	void encryptAndDecryptWithDefaultKey() {
		String text = "texto de prueba";
		String encrypted = AESUtil.encrypt(text);
		assertNotEquals(text, encrypted);
		assertEquals(text, AESUtil.decrypt(encrypted));
	}

	@Test
	void sameTextProducesDifferentCiphertexts() {
		assertNotEquals(AESUtil.encrypt("abc"), AESUtil.encrypt("abc"));
	}

	@Test
	void encryptAndDecryptWithExplicitKeyAndIv() {
		String key = "llavede16carater";
		String iv = "vectorinicial12b";
		String encrypted = AESUtil.encrypt(key, iv, "texto de prueba");
		assertEquals("texto de prueba", AESUtil.decrypt(key, iv, encrypted));
	}

	@Test
	void tamperedContentIsRejected() {
		String encrypted = AESUtil.encrypt("abc");
		String tampered = (encrypted.charAt(0) == 'A' ? "B" : "A") + encrypted.substring(1);
		assertThrows(RuntimeException.class, () -> AESUtil.decrypt(tampered));
	}

	@Test
	void invalidKeyLengthIsRejected() {
		assertThrows(IllegalArgumentException.class, () -> AESUtil.setDefaultKey("corta"));
	}

}
